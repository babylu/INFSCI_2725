import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Transform_movies {
	public static void main(String[] args) throws IOException{
		String position = "/Users/babylu/Desktop/Working&Study/GraduateStudy/2015-2016Spring/DataAnalysis/homework/Mongo_assignment_1_25_16/";
		BufferedReader br = new BufferedReader(
				new FileReader(position + "movies.dat"));
		BufferedWriter bw = new BufferedWriter(new FileWriter(position + "result/movies.json"));
		String line=null;
		while((line=br.readLine())!=null){
			//System.out.println(line);
			String newline = line.replaceAll("\\|", "::");
			newline = newline.replace("\"","\'");
			String[] a = newline.split("\\::");
			String[] b = new String[a.length-2] ;
			for(int i = 2 ;i <a.length;i++)
			{
				b[i-2] = a[i];
			}
			bw.write("{");
			bw.write("\"MovieID\""+":"+"\""+a[0]+"\""+",");
			bw.write("\"Title\""+":"+"\""+a[1]+"\""+",");
			bw.write("\"Genres\""+":"+"[");
			for(int j = 0 ;j < b.length ;j++)
			{
				if(j!=b.length -1)
					bw.write("\""+b[j]+"\""+",");
				else
					bw.write("\""+b[j]+"\"");
			}
			bw.write("]");
			bw.write("}");
			bw.newLine();
		}
		br.close();
		bw.close();
		System.out.println("FINISH!");
		
	}
}
