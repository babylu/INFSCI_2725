import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class Transform_ratings {
	public static void main(String[] args) throws IOException{
		String position = "/Users/babylu/Desktop/Working&Study/GraduateStudy/2015-2016Spring/DataAnalysis/homework/Mongo_assignment_1_25_16/";
		BufferedReader br = new BufferedReader(
				new FileReader(position + "ratings.dat"));
		BufferedWriter bw = new BufferedWriter(new FileWriter(position + "result/ratings.json"));
		String line=null;
		while((line=br.readLine())!=null){
			//System.out.println(line);
			String[] a = line.split("\\::");
			float b = Float.parseFloat(a[0]);
			float c = Float.parseFloat(a[1]);
			float d = Float.parseFloat(a[2]);
			float e = Float.parseFloat(a[3]);	
			bw.write("{");
			bw.write("\"UserID\""+":"+b+",");
			bw.write("\"MovieID\""+":"+c+",");
			bw.write("\"Rating\""+":"+d+",");
			bw.write("\"Timestamp\""+":"+e);
			bw.write("}");
			bw.newLine();
		}
		br.close();
		bw.close();
		System.out.println("FINISH!");
		
	}
}
