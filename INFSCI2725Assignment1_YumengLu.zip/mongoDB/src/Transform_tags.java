import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Transform_tags {
	public static void main(String[] args) throws IOException{
		String position = "/Users/babylu/Desktop/Working&Study/GraduateStudy/2015-2016Spring/DataAnalysis/homework/Mongo_assignment_1_25_16/";
		BufferedReader br = new BufferedReader(
				new FileReader(position + "/tags.dat"));
		BufferedWriter bw = new BufferedWriter(new FileWriter(position + "result/tags.json"));
		String line=null;
		while((line=br.readLine())!=null){
			//System.out.println(line);
			line = line.replace("\"","\'");
			String[] a = line.split("\\::");
			bw.write("{");
			bw.write("\"UserID\""+":"+"\""+a[0]+"\""+",");
			bw.write("\"MovieID\""+":"+"\""+a[1]+"\""+",");
			bw.write("\"Tag\""+":"+"\""+a[2]+"\""+",");
			bw.write("\"Timestamp\""+":"+"\""+a[3]+"\"");
			bw.write("}");
			bw.newLine();
		}
		br.close();
		bw.close();
		System.out.println("FINISH!");
		
	}
}
