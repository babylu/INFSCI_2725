import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;




public class mongoDBProject {
	public static void main(String args[]) {
		Mongo mongo = new Mongo("localhost", 27017);
		DB db = mongo.getDB("local");
		DBCollection collectionMovie = db.getCollection("movies");
		DBCollection collectionTag = db.getCollection("tags");
		DBCollection collectionRating = db.getCollection("ratings");
		
//		findCopyCat(collectionMovie);
//		CountGenres(collectionMovie);
//		findUserTags(collectionMovie,collectionTag);
//		findTopFiveMovies(collectionRating,collectionMovie);
//		findHighestRating(collectionRating);
//		findRatingBetween(collectionRating);
//		findRatingUnder(collectionRating);
		findTotalRatingAndNumPeople(collectionRating);
	}
	
	//question1
	public static void findCopyCat(DBCollection collection){
		DBCursor cursor = collection.find();
		String name;
		BasicDBObject node;
		while(cursor.hasNext()){
			node = (BasicDBObject) cursor.next();
			name = node.get("Title").toString();
			if(name.contains("Copycat")){
				String[] genre = node.get("Genres").toString().split(",");
				System.out.print("The Genre of Copycat is: ");
				for(String s:genre){
			    		String temp = s.substring(s.indexOf("\"")+1, s.lastIndexOf("\""));
			    		System.out.print(temp + " ");
				}
			}
		}
		
	}
	
	//question2
	public static void CountGenres(DBCollection collection) {
		DBCursor cursor = collection.find();
		Map<String, Integer> countMap = new HashMap<String, Integer>();
		String[] genres;
		while(cursor.hasNext()) {
		    genres = ((BasicDBObject) cursor.next()).get("Genres").toString().split(",");
		    for(String s:genres){
			    	String temp = s.substring(s.indexOf("\"")+1, s.lastIndexOf("\""));
			    	if(temp.contains("\"")){
			    		continue;
			    	}
			    	else{
				    	if(countMap.containsKey(temp)){
				    		countMap.replace(temp, countMap.get(temp)+1);
				    	}else{
				    		countMap.put(temp, 1);
				    	}
			    	}
		    }
		}
		for(String s: countMap.keySet()){
			System.out.println(s +"'s total number is :" + countMap.get(s)); 
		}
	}
	
	//question3
	public static void findUserTags(DBCollection collectionMovie,DBCollection collectionTag) {
		BasicDBObject queryMovieID = new BasicDBObject();
		queryMovieID.put("Title", "2001: A Space Odyssey (1968)");
		DBCursor cursorMovieID = collectionMovie.find(queryMovieID);
		String movieID = cursorMovieID.next().get("MovieID").toString();
		BasicDBObject queryTag = new BasicDBObject();
		Map<String,String> queryMap = new HashMap<String,String>();
		queryMap.put("MovieID", movieID);
		queryMap.put("UserID", "146");
		queryTag.putAll(queryMap);
		DBCursor cursorTag = collectionTag.find(queryTag);
		String tag;
		while(cursorTag.hasNext()){
			tag = cursorTag.next().get("Tag").toString();
			System.out.println(tag);
		}
	}
	
	//question4	
	public static void findTopFiveMovies(DBCollection collectionRating,DBCollection collectionMovie) {
		BasicDBObject queryAveRating = new BasicDBObject();
		queryAveRating.put("$group", new BasicDBObject("_id", "$MovieID").append("average rating", new BasicDBObject("$avg", "$Rating")));
		DBObject sort = new BasicDBObject("$sort", new BasicDBObject("average rating",-1));
		AggregationOutput output = collectionRating.aggregate(queryAveRating, sort);
		Iterator<DBObject> outputIterator = output.results().iterator();
		int i = 0;
		String[] movieIDs = new String[5];
		while(outputIterator.hasNext() && i<5){
			String string = outputIterator.next().toString();
			movieIDs[i] = string.split(",")[0].split(":")[1].trim();
			i++;
		}
		
		String[] name = new String[movieIDs.length];
		int j = 0;
		for(String s:movieIDs){
			BasicDBObject queryMovieTitle = new BasicDBObject();
			queryMovieTitle.put("MovieID", s);
			DBCursor cursorMovieTitle = collectionMovie.find(queryMovieTitle);
			name[j] = cursorMovieTitle.next().get("Title").toString();
			System.out.println(name[j]);
			j++;
		}
	}
	
	//question5
	public static void findHighestRating(DBCollection collectionRating) {
		BasicDBObject queryAveRating = new BasicDBObject();
		queryAveRating.put("$group", new BasicDBObject("_id", "$MovieID").append("average rating", new BasicDBObject("$avg", "$Rating")));
		DBObject sort = new BasicDBObject("$sort", new BasicDBObject("average rating",-1));
		AggregationOutput output = collectionRating.aggregate(queryAveRating, sort);
		Iterator<DBObject> outputIterator = output.results().iterator();
		String rawRating = outputIterator.next().toString().split(",")[1].split(":")[1].trim();
		String rating = rawRating.substring(0,rawRating.length()-1);
		System.out.println(rating);
	}
	
	//question6(1)
	public static void findRatingBetween(DBCollection collectionRating){
		BasicDBObject queryAveRating = new BasicDBObject();
		queryAveRating.put("$group", new BasicDBObject("_id", "$MovieID").append("average rating", new BasicDBObject("$avg", "$Rating")));
		DBObject sort = new BasicDBObject("$sort", new BasicDBObject("average rating",-1));
		AggregationOutput output = collectionRating.aggregate(queryAveRating, sort);
		Iterator<DBObject> outputIterator = output.results().iterator();
		ArrayList<String> movieIDs = new ArrayList<>();
		while(outputIterator.hasNext()){
			String string = outputIterator.next().toString();
			String rawRating = string.split(",")[1].split(":")[1].trim();
			float rating = Float.parseFloat(rawRating.substring(0,rawRating.length()-1));
			if(rating<5 && rating>4){
				movieIDs.add(string.split(",")[0].split(":")[1].trim());
			}
		}
		for(int i=0;i<movieIDs.size();i++){
			System.out.println(movieIDs.get(i));
		}
	}
	
	//question6(2)
	public static void findRatingUnder(DBCollection collectionRating){
		BasicDBObject queryAveRating = new BasicDBObject();
		queryAveRating.put("$group", new BasicDBObject("_id", "$MovieID").append("average rating", new BasicDBObject("$avg", "$Rating")));
		DBObject sort = new BasicDBObject("$sort", new BasicDBObject("average rating",1));
		AggregationOutput output = collectionRating.aggregate(queryAveRating, sort);
		Iterator<DBObject> outputIterator = output.results().iterator();
		int count = 0;
		while(outputIterator.hasNext()){
			String string = outputIterator.next().toString();
			String rawRating = string.split(",")[1].split(":")[1].trim();
			float rating = Float.parseFloat(rawRating.substring(0,rawRating.length()-1));
			if(rating<2){
				count ++;
			}
		}
		System.out.println(count);
	}
	
	//question6(3)
	public static void findTotalRatingAndNumPeople(DBCollection collectionRating){
		BasicDBObject querySumRating = new BasicDBObject();
		querySumRating.put("$group", new BasicDBObject("_id", "$MovieID").append("sum rating", new BasicDBObject("$sum", "$Rating")).append("count number", new BasicDBObject("$sum", 1)));
		AggregationOutput output = collectionRating.aggregate(querySumRating);
		Iterator<DBObject> outputIterator = output.results().iterator();
		while(outputIterator.hasNext()){
			System.out.println(outputIterator.next().toString());
		}
	}
}
